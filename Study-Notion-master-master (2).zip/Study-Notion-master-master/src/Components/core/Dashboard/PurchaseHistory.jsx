import React from 'react'

const PurchaseHistory = () => {
  return (
    <div>PurchaseHistory</div>
  )
}

export default PurchaseHistory